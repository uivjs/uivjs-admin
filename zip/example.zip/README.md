uivjs-admin
===

Vue 3.0 admin management system template.

## Open in CodeSandbox

[![Open in CodeSandbox](https://img.shields.io/badge/Open%20in-CodeSandbox-blue?logo=codesandbox)](https://codesandbox.io/s/github/uivjs/uivjs-admin/tree/master/example/)

Download the example directly to the local preview: [`uiv-admin.zip`](https://uivjs.github.io/uivjs-admin/zip/example.zip) for Github, [`uiv-admin.zip`](https://uivjs.gitee.io/uivjs-admin/zip/example.zip) for Gitee.

## Project setup
```
npm install
```

### Compiles and hot-reloads for development

```
npm run serve
```

### Compiles and minifies for production

```
npm run build
```

### Lints and fixes files

```
npm run lint
```

### Customize configuration

See [Configuration Reference](https://cli.vuejs.org/config/).
